#ifndef GPIO_H_INCLUDED
#define GPIO_H_INCLUDED
int led_setup(void);
void blue_led_on(void);
void blue_led_off(void);
void blue_led_toggle(void);
void red_led_on(void);
void red_led_off(void);
void red_led_toggle(void);
#endif
