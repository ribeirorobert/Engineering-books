#ifndef SYSTICK_H_INCLUDED
#define SYSTICK_H_INCLUDED
extern volatile unsigned int jiffies;
void systick_enable(void);
#endif
