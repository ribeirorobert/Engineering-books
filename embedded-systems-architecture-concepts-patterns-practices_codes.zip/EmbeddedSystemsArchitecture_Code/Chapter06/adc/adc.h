#ifndef ADC_H_INCLUDED
#define ADC_H_INCLUDED

int adc_init(void);
int adc_read(void);
#endif
