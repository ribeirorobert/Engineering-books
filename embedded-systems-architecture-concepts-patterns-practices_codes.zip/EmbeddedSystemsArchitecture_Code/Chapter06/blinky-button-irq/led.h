#ifndef GPIO_H_INCLUDED
#define GPIO_H_INCLUDED
int led_setup(void);
void led_on(void);
void led_off(void);
void led_toggle(void);
#endif
