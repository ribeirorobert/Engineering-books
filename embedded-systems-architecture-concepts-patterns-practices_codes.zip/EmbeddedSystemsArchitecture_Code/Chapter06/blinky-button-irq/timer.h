#ifndef TIMER_H_INCLUDED
#define TIMER_H_INCLUDED
void timer_init(uint32_t clock, uint32_t prescaler, uint32_t interval_ms);

#endif
